﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using IEDInventoryQueryEngine.Models;
using System.Net.Http;
using Newtonsoft.Json;



namespace IEDInventoryQueryEngine.Controllers
{
    public class HomeController : Controller
    {
        /*
            These lines are needed to use the Database context,
            define the connection to the API, and use the
            HttpClient to request data from the API
        */

        //Base URL for the SEL API. Method specific URLs are appended to this base URL.
        string BASE_URL = "http://localhost:5230/";
        //string BASE_URL = "http://TRINITYTRNGPC:5230/";
        HttpClient httpClient;

        /*
         These lines create a Constructor for the HomeController.
         Then, the Database context is defined in a variable.
         Then, an instance of the HttpClient is created.
        */
        public HomeController()
        {
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new
                System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        public SEL_Model GetSEL_Model(string ADD_ON_API_QUERY_PATH)
        {
            string SEL_Relay_Device_API_PATH = BASE_URL + ADD_ON_API_QUERY_PATH;
            string SEL_Model_List = "";
            //List<Relay_Models> relay_Models = null;
            SEL_Model sel_Model = null;// new SEL_Model();

            //Connect to SEL Database API and retrieve the information 
            httpClient.BaseAddress = new Uri(SEL_Relay_Device_API_PATH);

            try
            {
                HttpResponseMessage response = httpClient.GetAsync(SEL_Relay_Device_API_PATH).GetAwaiter().GetResult();

                //Read the Json objects in the API response
                if (response.IsSuccessStatusCode)
                {
                    SEL_Model_List = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                }

                //Now parse Json string to C# objects
                if (!SEL_Model_List.Equals(""))
                {
                    // JsonConvert is part of the NewtonSoft.Json Nuget package
                    sel_Model = JsonConvert.DeserializeObject<SEL_Model>(SEL_Model_List);

                }

            }
            catch (Exception e)
            {
                // This is a useful place to insert a breakpoint and observe the error message
                Console.WriteLine(e.Message);
            }

            return sel_Model;
        }
        public IActionResult Index(string Searchtxt1, string Searchtxt2, string Searchtxt3)
        {
            string ADD_ON_API_QUERY_PATH = "api/device";
            HomeController webHandler = new HomeController();
            SEL_Model sel_Model = webHandler.GetSEL_Model(ADD_ON_API_QUERY_PATH);
            string url_addon, url_addon_with_SEL = null;
            string sel_product_latest_FW_versions_url_path = null;
            string sel_product_base_link = "https://selinc.com/products/";
            string sel_product_config_summary_base_link = "https://selinc.com/products/summary/?partNumber=";
            string sel_product_latest_FW_versions_base_link = "https://selinc.com/products/firmware/?versionProduct=";

            url_addon = Searchtxt1;
            if (!string.IsNullOrEmpty(Searchtxt1))
            {
                url_addon = Searchtxt1.ToUpper();
            }

            int count = 0;
            int SpecialCharCount = 0;
            int Firstdigitflag = 0;

            string PartialDeviceType = "";
            string PartialDeviceType_with_SEL = "";

            if (!string.IsNullOrEmpty(Searchtxt1))
            {
                for (int i = 0; i < Searchtxt1.Length; i++)
                {
                    if (Char.IsLetter(Searchtxt1[0]))
                    {
                        if (Char.IsLetterOrDigit(Searchtxt1[i]) && count < 2)
                        {
                            PartialDeviceType += Searchtxt1[i];
                            PartialDeviceType_with_SEL += Searchtxt1[i];
                        }
                        else
                        {
                            if ((count != 1) && (i < Searchtxt1.Length - 1))
                            {
                                PartialDeviceType = "";
                            }
                            count++;
                            if (count < 2)
                            {
                                PartialDeviceType_with_SEL += Searchtxt1[i];
                            }
                        }
                    }
                    else
                    {
                        if ((Char.IsDigit(Searchtxt1[i]) && SpecialCharCount == 1) && (!Char.IsLetterOrDigit(Searchtxt1[0])))
                        {
                            if (i == 1)
                            {
                                PartialDeviceType_with_SEL = "SEL-"+Searchtxt1[1];
                            }
                            else
                            {
                                PartialDeviceType_with_SEL += Searchtxt1[i];
                            }
                        }
                        if ((Char.IsDigit(Searchtxt1[0]) && SpecialCharCount == 0 && Firstdigitflag == 0))
                        {
                            PartialDeviceType_with_SEL = "SEL-"+Searchtxt1[i];
                            Firstdigitflag++;
                        }
                        else if((!Char.IsLetterOrDigit(Searchtxt1[i])) && SpecialCharCount < 2)
                        {
                            if (i==0 && SpecialCharCount ==0)
                            {
                                PartialDeviceType_with_SEL = "";
                            }
                            else
                            {
                                PartialDeviceType_with_SEL += Searchtxt1[i];
                            }
                            SpecialCharCount++;
                        }
                        else
                        {
                            if (Char.IsLetterOrDigit(Searchtxt1[i])&&SpecialCharCount==0)
                            {
                                PartialDeviceType_with_SEL += Searchtxt1[i];
                            }
                        }

                        if (Char.IsLetterOrDigit(Searchtxt1[i]) && count < 1)
                        {
                            PartialDeviceType += Searchtxt1[i];
                        }
                        else
                        {
                            count++;
                        }
                    }
                }
                url_addon = PartialDeviceType.ToUpper();
                url_addon_with_SEL = PartialDeviceType_with_SEL.ToUpper();
            }

            string Search_product_url_path = sel_product_base_link + url_addon;
            sel_product_latest_FW_versions_url_path = sel_product_latest_FW_versions_base_link + url_addon_with_SEL; //change posistion

            if (!string.IsNullOrEmpty(Searchtxt1) && !string.IsNullOrEmpty(Searchtxt2))
            {
                string id = Searchtxt1.ToUpper();
                string id2 = Searchtxt2.ToUpper();
                if (id2 == "TRUE")
                { id2 = "true"; }
                if (id2 == "FALSE")
                { id2 = "false"; }

                sel_Model.Data = (List<DeviceData>)sel_Model.Data.Where(x => x.DeviceType.Contains(id) && (x.DeviceId == id2 || x.DeviceName == id2 || x.DeviceType == id2 || x.IsInService == id2 || x.FirmwareVersion == id2 || x.FidString == id2 || x.SerialNumber == id2 || x.PartNumber == id2)).ToList();
            }
            else if ((!string.IsNullOrEmpty(Searchtxt1)) && string.IsNullOrEmpty(Searchtxt2))
            {
                string id = Searchtxt1.ToUpper();
                sel_Model.Data = (List<DeviceData>)sel_Model.Data.Where(x => x.DeviceType.Contains(id) || x.DeviceId == id || x.DeviceName == id || x.DeviceType == id || x.IsInService == id || x.FirmwareVersion == id || x.FidString == id || x.SerialNumber == id || x.PartNumber == id).ToList();
            }
            else if (string.IsNullOrEmpty(Searchtxt1) && !string.IsNullOrEmpty(Searchtxt2))
            {
                string id2 = Searchtxt2.ToUpper();
                if (id2 == "TRUE")
                { id2 = "true"; }
                if (id2 == "FALSE")
                { id2 = "false"; }
                sel_Model.Data = (List<DeviceData>)sel_Model.Data.Where(x => x.DeviceType.Contains(id2) || x.DeviceId == id2 || x.DeviceName == id2 || x.DeviceType == id2 || x.IsInService == id2 || x.FirmwareVersion == id2 || x.FidString == id2 || x.SerialNumber == id2 || x.PartNumber == id2).ToList();
            }

            ViewData["Search1_product_url"] = Search_product_url_path;
            ViewData["Search2_DeviceType"] = url_addon;
            ViewData["Latest_FW_Version_url"] = sel_product_latest_FW_versions_url_path;

            if (!string.IsNullOrEmpty(Searchtxt3))
            {
                string Product_Config_Summary_url_path = sel_product_config_summary_base_link + Searchtxt3;
                ViewData["Search3_product_config_Summary_url"] = Product_Config_Summary_url_path;
                ViewData["Search4_part_number"] = Searchtxt3;
            }
            else
            {
                string Product_Config_Summary_url_path = null + Searchtxt3;
            }


            return View(sel_Model);
        }

        public IActionResult Product_Category(string prod_category)
        {
            string ADD_ON_API_QUERY_PATH = "api/device";
            HomeController webHandler = new HomeController();
            SEL_Model sel_Model = webHandler.GetSEL_Model(ADD_ON_API_QUERY_PATH);

            if (!string.IsNullOrEmpty(prod_category))
            {
                sel_Model.Data = (List<DeviceData>)sel_Model.Data.Where(x => x.DeviceType.Contains(prod_category) && (x.DeviceId == prod_category)).ToList();
            }

            return View();
        }
        public IActionResult Help()
        {
            return View();
        }
        public IActionResult AdvancedSearch()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
